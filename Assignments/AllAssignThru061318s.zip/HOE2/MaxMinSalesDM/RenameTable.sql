﻿USE PalumboSalesDM
EXEC sp_rename 'Store1', 'Store';