/****** Script for SelectTopNRows command from SSMS  ******/
SELECT *
  FROM [PalumboManufacturingDM].[dbo].[DimMachine]

SELECT *
  FROM [PalumboManufacturingDM].[dbo].[DimMachineType]

SELECT *
  FROM [PalumboManufacturingDM].[dbo].[DimMaterial]

SELECT *
  FROM [PalumboManufacturingDM].[dbo].[DimProduct]

SELECT *
  FROM [PalumboManufacturingDM].[dbo].[DimProductType]

SELECT *
  FROM [PalumboManufacturingDM].[dbo].[DimProductSubtype]

SELECT *
  FROM [PalumboManufacturingDM].[dbo].[DimCountry]

SELECT *
  FROM [PalumboManufacturingDM].[dbo].[DimPlant]
